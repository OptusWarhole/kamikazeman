Game : Bomberman

It supports only 4 players and features like netplay, AI bots, pushing bombs, ...

You have to lauch one server, and then connect 4 players to the server.


How to launch the server:

- make all
- ./server


Then, on player's host : 

- "IP address" 4242 or in local 0 4242
